let campoIdade;
let campoFantasia;
let campoAventura;

function setup() {
  createCanvas(800, 400);
  createElement("De repente 30");
  createSpan("livre");
  campoIdade = createInput("5");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
}

function draw() {
  background("white");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura) {
  if (idade >= 10) {
    if (idade >= 12) {
      return "As Patricinhas de Beverly Hills";
    } else {
      if (idade >= 12) {
        if(gostaDeFantasia || gostaDeAventura) {
          return "Barraca do beijo";          
        } else{
         return "barraca do beijo 2";
        }
      } else {
        if (gostaDeFantasia) {
          return "Para todos os garrotos que já amei";
        } else {
          return "Para todos os garrotos que já amei ps ainda amo";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return " Programa de Proteção para Princesas";
    } else {
      return "Elementos";
    }
  }
}
